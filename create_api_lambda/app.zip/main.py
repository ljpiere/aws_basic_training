import requests


def call_external():
    BASE_URL = "https://swapi.dev"
    END_POINT = "api/planets/1/"
    resp = requests.get(f"{BASE_URL}/{END_POINT}")
    data = []
    if resp.status_code == 200:
        data = resp.json()
    #return data

    #data = call_external()  # call your external services

    return {
        "status_code": 200,
        "success": True,
        "message": "Success get starwars data",
        "data": data
    }

dos = call_external()

print(dos)